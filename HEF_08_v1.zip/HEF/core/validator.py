import re
class Validar():

   

#====================validação- CARAC. ESPECIAL =====================

   
    def val_especial(dado):
        insert= len(dado) #recebe o dado inserido
        modifica =  re.search ("[!@#$%¨&*()_-+=?/:;<>]", insert) #procura nos dados os caracteres indicados
        if modifica == True: #condicao: se for achado...
            return True
        return False

#=======================validação - NUMEROS ==========================

         
    def validar_numero(valor):
        try:
            float(valor)  # aceita inteiro e decimal
            return True
        except ValueError:
            return False

#==========================validação - QUANTIDADE=======================


 
    def validar_quantidade(qtd):

        if not qtd.isdigit():
            return False

        qtd = int(qtd)

        if qtd <= 0:
            return False

        return True


#==============================validação - TEXTO=======================

        

 
#converte tudo pra letra
    def val_texto_letra(texto):
        tem_letra = False

        for caractere in texto:
            if caractere.isalpha(): #transforma em letra
                tem_letra = True

        return tem_letra

#Validar quantidade max e min de caracters 
    def val_texto_minmax(texto):

        texto = texto.strip()

        return 1 <= len(texto) <= 50

#validar se tem espaço
    def val_texto_espaco(texto):
        
        possui_espaco = True

        for caractere in texto:
            if caractere.isspace():
                possui_espaco = False

            if not possui_espaco:
                return {"valida": False, "Mensagem": "Não deve possuir espaço!"}
            return True

        return True



    def val_maiusculo(texto):

        return texto.isupper()


        try:
            response = requests.get(url, params=params)   #Envia a requisição GET com os parâmetros
            response.raise_for_status( ) #Levanta exceção para status HTTP de erro
            data =  response.json()#Converte a resposta para JSON
            return data
    
        #lista de erros
        except requests.exceptions.HTTPError as errh:
            print("Erro HTTP:",errh)
        except requests.exceptions.ConnectionError as errc:
            print("Erro de conexão:",errc)
        except requests.exceptions.TimeoutError as errt:
            print("Timeout:",errt)
        except requests.exceptions.RequestExcention as err:
            print("Erro:", err)

        return None
            
        

   
       
  





